#sleep 30
#/mnt/mmc/mods/telnetd &
/sdcard/mods/keyscan360 /dev/event0 /dev/event1 /sdcard/mods/ &
st led 2 on; st led 2 off

